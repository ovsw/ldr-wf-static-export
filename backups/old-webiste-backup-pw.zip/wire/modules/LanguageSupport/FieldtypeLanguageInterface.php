<?php namespace ProcessWire;

// moved to /wire/core/Interfaces.php

