sass --style=compressed main.scss:main.css
sass --style=compressed classic.scss:classic.css
sass --style=compressed blue.scss:blue.css
sass --style=compressed blue.scss:blue.css
