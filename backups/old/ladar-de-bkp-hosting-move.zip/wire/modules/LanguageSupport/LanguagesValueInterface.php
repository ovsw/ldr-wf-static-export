<?php

/**
 * Interface for multi-language fields
 *
 * ProcessWire 2.x 
 * Copyright (C) 2015 by Ryan Cramer 
 * This file licensed under Mozilla Public License v2.0 http://mozilla.org/MPL/2.0/
 * 
 * https://processwire.com
 * 
 * Moved to /wire/core/Interfaces.php
 *
 */



